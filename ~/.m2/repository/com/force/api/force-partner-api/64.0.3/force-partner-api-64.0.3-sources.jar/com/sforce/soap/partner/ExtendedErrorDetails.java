/*
 * Copyright (c) 2005-2016 salesforce.com, inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *    Redistributions of source code must retain the above copyright notice, this list of conditions and the
 *    following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
 *    the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 *    Neither the name of salesforce.com, inc. nor the names of its contributors may be used to endorse or
 *    promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.sforce.soap.partner;

import com.sforce.ws.bind.XmlObject;
import com.sforce.soap.partner.ExtendedErrorCode;

/**
 * ExtendedErrorDetails is loosely typed. You can use {@link #getField(String)} to get the information 
 */
public class ExtendedErrorDetails extends XmlObject implements IExtendedErrorDetails{

	/**
	 * @return the details associated with the field. You can find the fields to expect for 
	 * the given {@link #getExtendedErrorCode()} in the wsdl, or online documentation. 
	 */
	@Override
    public Object getField(String name) {
        return super.getField(name);
    }

	@Override
    public ExtendedErrorCode getExtendedErrorCode() {
    	String extendedErrorCode = (String)getField("extendedErrorCode");
    	if (extendedErrorCode != null) {
    		return ExtendedErrorCode.valueOf(extendedErrorCode);
    	}
        return null;
    }
}
